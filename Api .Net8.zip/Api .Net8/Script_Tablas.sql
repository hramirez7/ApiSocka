

CREATE TABLE Persona (
    Id INT PRIMARY KEY IDENTITY(1,1), -- Clave primaria
    Nombre NVARCHAR(100),
    Genero NVARCHAR(10),
    Edad INT,
    Identificacion NVARCHAR(50) UNIQUE, -- Clave �nica
    Direccion NVARCHAR(200),
    Telefono NVARCHAR(15)
);

CREATE TABLE Cliente (
    ClienteId INT PRIMARY KEY IDENTITY(1,1), -- Clave primaria
    Contrase�a NVARCHAR(100),
    Estado bit,
    PersonaId INT UNIQUE -- Relaci�n con Persona
   -- FOREIGN KEY (PersonaId) REFERENCES Persona(Id) -- Clave for�nea
);

CREATE TABLE Cuenta (
    CuentaId INT PRIMARY KEY IDENTITY(1,1), -- Clave primaria
	NumeroCuenta int ,
    TipoCuenta NVARCHAR(50),
    SaldoInicial DECIMAL(18,2),
    Estado NVARCHAR(20),
    ClienteId INT  -- Relaci�n con Cliente
  --  FOREIGN KEY (ClienteId) REFERENCES Cliente(ClienteId) -- Clave for�nea
);

CREATE TABLE Movimientos (
    MovimientoId INT PRIMARY KEY IDENTITY(1,1), -- Clave primaria
    Fecha int,
    TipoMovimiento NVARCHAR(20),
    Valor DECIMAL(18,2),
    Saldo DECIMAL(18,2),
    CuentaNumero INT -- Relaci�n con Cuenta
  --  FOREIGN KEY (CuentaNumero) REFERENCES Cuenta(NumeroCuenta) -- Clave for�nea
);